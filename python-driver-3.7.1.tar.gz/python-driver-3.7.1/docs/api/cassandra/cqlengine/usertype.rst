``cassandra.cqlengine.usertype`` - Model classes for User Defined Types
=======================================================================

.. module:: cassandra.cqlengine.usertype

UserType
--------
.. autoclass:: UserType

    .. autoattribute:: __type_name__
