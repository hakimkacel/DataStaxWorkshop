``cassandra.io.eventletreactor`` - ``eventlet``-compatible Connection
=====================================================================

.. module:: cassandra.io.eventletreactor

.. autoclass:: EventletConnection
   :members:
