``cassandra.io.asyncorereactor`` - ``asyncore`` Event Loop
==========================================================

.. module:: cassandra.io.asyncorereactor

.. autoclass:: AsyncoreConnection
   :members:
