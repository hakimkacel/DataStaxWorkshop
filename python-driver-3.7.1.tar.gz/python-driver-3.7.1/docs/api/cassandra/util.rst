``cassandra.util`` - Utilities
===================================

.. automodule:: cassandra.util
    :members: 
